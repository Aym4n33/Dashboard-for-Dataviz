from website import app
if __name__ == '__main__': # C'est pour dire que l'application sera lancée uniquement si ce fichier est executé
    app.run(debug=True)