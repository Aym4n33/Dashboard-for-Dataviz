import json
import folium
from flask import request, jsonify









with open(r'../data manager/colleges_avec_gps.json','r') as f :
    colleges = json.load(f)
















